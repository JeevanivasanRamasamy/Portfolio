<?php

$dbServername = "localhost";
$dbUsername = "id14748725_jeeva";
$dbPassword = "Wu78#m+o<)Ak33N!";
$dbName = "id14748725_adsite";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

if (!$conn) {
	die("connection failed: ".mysqli_connect_error());
}