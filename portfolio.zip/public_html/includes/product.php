<?php 
error_reporting(0); 
$con=new mysqli('localhost','id14748725_jeeva','Wu78#m+o<)Ak33N!','id14748725_adsite');
if($con->connect_errno) 
{
  echo $con->connect_error;
  die();
}
				if (isset($_POST['submit'])) 
				{
					$category=$_POST['category'];
					$brand=$_POST['brand'];
					$name=$_POST['name'];
					$availablity=$_POST['availablity'];
					$email=$_POST['email'];
					$more=$_POST['more'];
					$sql="INSERT INTO product (category,brand,name,availablity,email,more) VALUES ('$category','$brand','$name','$availablity','$email','$more')";
					if ($con->query($sql)) 
					{

						header('Location: ../explore.php?msgproduct=<p class="signupessage">Success, Click below to view posted ad</p>');
					}
					else
					{
						echo "image not stored";	
					}
				}
				else
				{
					echo "plese enter fields";
				}

?>