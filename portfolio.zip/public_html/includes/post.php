<?php

error_reporting(0); 
$con=new mysqli('localhost','id14748725_jeeva','Wu78#m+o<)Ak33N!','id14748725_adsite');
if($con->connect_errno) 
{
  echo $con->connect_error;
  die();
}
				if (isset($_POST['submit'])) 
				{
					if (getimagesize($_FILES['image']['tmp_name'])==false) 
					{
						echo "select image";
					}
					else
					{
						$image=$_FILES['image'] ['tmp_name'];
						$name=$_FILES['image'] ['name'];

						$image=file_get_contents($image);
						$image=base64_encode($image);
						$comments=$_POST['comments'];
						$sql="INSERT INTO post (name,image,comments) VALUES ('$name','$image','$comments')";
					if ($con->query($sql)) 
					{

						header("Location: ../explore.php?msgpost=<p class='signupessage'>Success, Click below to view post</p>");
					}
					else
					{
						echo "image not stored";	
					}
					}
				}
				else
				{
						echo "select image and add caption";
				}

?>